
Terrorist Bomb - v2
Proyecto generado automáticamente.

Estructura:
- index.html
- css/styles.css
- js/game.js
- assets/images/*.png
- assets/sounds/*.wav

Notas:
- El juego ya incluye sprites PNG básicos y WAVs generados programáticamente (placeholders).
- Reemplaza los archivos en assets/ por tus propios recursos si quieres mejorar audio o gráficos.
- No hay backend incluido aquí (tu backend se integrará en /api/... si lo deseas).

Instrucciones:
1) Descomprime el ZIP.
2) Sirve la carpeta con un servidor estático (recomendado: `npx http-server` o `python -m http.server 8000` desde la carpeta).
3) Abre http://localhost:8080 (o el puerto que uses).
